﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Library
{
    class Customer : Person
    {
        private string _custID { get; set; }

        public Customer() { }
        public Customer(string custid, string fname, string sname, string email, string gender, string contactno, string dob,string address)
            : base(fname, sname, email, gender, contactno, dob, address)
        {
            this._custID = custid;
        }

       // public ~Customer() { }
    }
}

﻿namespace Game_Library
{
    partial class staffList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.liststfdata = new System.Windows.Forms.DataGridView();
            this.idNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this._numstf = new System.Windows.Forms.Label();
            this.Exit = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.Edit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.save = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.tp_box = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.a_box = new System.Windows.Forms.TextBox();
            this.pn_box = new System.Windows.Forms.TextBox();
            this.e_box = new System.Windows.Forms.TextBox();
            this.dh_box = new System.Windows.Forms.TextBox();
            this.cn_box = new System.Windows.Forms.TextBox();
            this.dob_box = new System.Windows.Forms.TextBox();
            this.g_box = new System.Windows.Forms.TextBox();
            this.sn_box = new System.Windows.Forms.TextBox();
            this.fn_box = new System.Windows.Forms.TextBox();
            this.sid_box = new System.Windows.Forms.TextBox();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageStaddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageCustomerDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageGameDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.overdueGamesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountTransactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.dataBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataRestoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetPasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.liststfdata)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // liststfdata
            // 
            this.liststfdata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.liststfdata.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idNum,
            this.name,
            this.email,
            this.type});
            this.liststfdata.Location = new System.Drawing.Point(0, 104);
            this.liststfdata.Name = "liststfdata";
            this.liststfdata.Size = new System.Drawing.Size(579, 467);
            this.liststfdata.TabIndex = 2;
            this.liststfdata.SelectionChanged += new System.EventHandler(this.liststfdata_SelectionChanged);
            // 
            // idNum
            // 
            this.idNum.HeaderText = "staff ID";
            this.idNum.Name = "idNum";
            this.idNum.ReadOnly = true;
            this.idNum.Width = 125;
            // 
            // name
            // 
            this.name.HeaderText = "Name";
            this.name.Name = "name";
            this.name.ReadOnly = true;
            this.name.Width = 145;
            // 
            // email
            // 
            this.email.HeaderText = "Email";
            this.email.Name = "email";
            this.email.ReadOnly = true;
            this.email.Width = 165;
            // 
            // type
            // 
            this.type.HeaderText = "Type";
            this.type.Name = "type";
            this.type.ReadOnly = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "# Staffs: ";
            // 
            // _numstf
            // 
            this._numstf.AutoSize = true;
            this._numstf.Location = new System.Drawing.Point(59, 75);
            this._numstf.Name = "_numstf";
            this._numstf.Size = new System.Drawing.Size(0, 13);
            this._numstf.TabIndex = 5;
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(862, 49);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 29);
            this.Exit.TabIndex = 6;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(50, 400);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(75, 29);
            this.Delete.TabIndex = 7;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Edit
            // 
            this.Edit.Location = new System.Drawing.Point(146, 400);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(75, 29);
            this.Edit.TabIndex = 8;
            this.Edit.Text = "Edit";
            this.Edit.UseVisualStyleBackColor = true;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(183, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // searchBox
            // 
            this.searchBox.Location = new System.Drawing.Point(15, 37);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(162, 20);
            this.searchBox.TabIndex = 11;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(582, 104);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(355, 467);
            this.tabControl1.TabIndex = 54;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.save);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.tp_box);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.Delete);
            this.tabPage1.Controls.Add(this.Edit);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.a_box);
            this.tabPage1.Controls.Add(this.pn_box);
            this.tabPage1.Controls.Add(this.e_box);
            this.tabPage1.Controls.Add(this.dh_box);
            this.tabPage1.Controls.Add(this.cn_box);
            this.tabPage1.Controls.Add(this.dob_box);
            this.tabPage1.Controls.Add(this.g_box);
            this.tabPage1.Controls.Add(this.sn_box);
            this.tabPage1.Controls.Add(this.fn_box);
            this.tabPage1.Controls.Add(this.sid_box);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(347, 441);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Detail";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // save
            // 
            this.save.Location = new System.Drawing.Point(238, 400);
            this.save.Name = "save";
            this.save.Size = new System.Drawing.Size(75, 29);
            this.save.TabIndex = 55;
            this.save.Text = "Save";
            this.save.UseVisualStyleBackColor = true;
            this.save.Click += new System.EventHandler(this.save_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(45, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 13);
            this.label13.TabIndex = 20;
            this.label13.Text = "Employee Type:";
            // 
            // tp_box
            // 
            this.tp_box.Location = new System.Drawing.Point(155, 101);
            this.tp_box.Name = "tp_box";
            this.tp_box.ReadOnly = true;
            this.tp_box.Size = new System.Drawing.Size(156, 20);
            this.tp_box.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(45, 321);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 13);
            this.label12.TabIndex = 18;
            this.label12.Text = "Address:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(45, 290);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 13);
            this.label11.TabIndex = 17;
            this.label11.Text = "Date Hire:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(45, 259);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "PPSN: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(45, 228);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Email:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(45, 197);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Contact #:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 166);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "DOB: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(45, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Gender:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(45, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Second Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "First Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Staff id:";
            // 
            // a_box
            // 
            this.a_box.Location = new System.Drawing.Point(155, 318);
            this.a_box.Multiline = true;
            this.a_box.Name = "a_box";
            this.a_box.ReadOnly = true;
            this.a_box.Size = new System.Drawing.Size(156, 70);
            this.a_box.TabIndex = 8;
            // 
            // pn_box
            // 
            this.pn_box.Location = new System.Drawing.Point(155, 256);
            this.pn_box.Name = "pn_box";
            this.pn_box.ReadOnly = true;
            this.pn_box.Size = new System.Drawing.Size(156, 20);
            this.pn_box.TabIndex = 7;
            // 
            // e_box
            // 
            this.e_box.Location = new System.Drawing.Point(155, 225);
            this.e_box.Name = "e_box";
            this.e_box.ReadOnly = true;
            this.e_box.Size = new System.Drawing.Size(156, 20);
            this.e_box.TabIndex = 6;
            // 
            // dh_box
            // 
            this.dh_box.Location = new System.Drawing.Point(155, 287);
            this.dh_box.Name = "dh_box";
            this.dh_box.ReadOnly = true;
            this.dh_box.Size = new System.Drawing.Size(156, 20);
            this.dh_box.TabIndex = 6;
            // 
            // cn_box
            // 
            this.cn_box.Location = new System.Drawing.Point(155, 194);
            this.cn_box.Name = "cn_box";
            this.cn_box.ReadOnly = true;
            this.cn_box.Size = new System.Drawing.Size(156, 20);
            this.cn_box.TabIndex = 5;
            // 
            // dob_box
            // 
            this.dob_box.Location = new System.Drawing.Point(155, 163);
            this.dob_box.Name = "dob_box";
            this.dob_box.ReadOnly = true;
            this.dob_box.Size = new System.Drawing.Size(156, 20);
            this.dob_box.TabIndex = 4;
            // 
            // g_box
            // 
            this.g_box.Location = new System.Drawing.Point(155, 132);
            this.g_box.Name = "g_box";
            this.g_box.ReadOnly = true;
            this.g_box.Size = new System.Drawing.Size(156, 20);
            this.g_box.TabIndex = 3;
            // 
            // sn_box
            // 
            this.sn_box.Location = new System.Drawing.Point(155, 70);
            this.sn_box.Name = "sn_box";
            this.sn_box.ReadOnly = true;
            this.sn_box.Size = new System.Drawing.Size(156, 20);
            this.sn_box.TabIndex = 2;
            // 
            // fn_box
            // 
            this.fn_box.Location = new System.Drawing.Point(155, 39);
            this.fn_box.Name = "fn_box";
            this.fn_box.ReadOnly = true;
            this.fn_box.Size = new System.Drawing.Size(156, 20);
            this.fn_box.TabIndex = 1;
            // 
            // sid_box
            // 
            this.sid_box.Location = new System.Drawing.Point(155, 8);
            this.sid_box.Name = "sid_box";
            this.sid_box.ReadOnly = true;
            this.sid_box.Size = new System.Drawing.Size(156, 20);
            this.sid_box.TabIndex = 0;
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.settingToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(940, 24);
            this.menuStrip2.TabIndex = 55;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAddToolStripMenuItem,
            this.manageStaddToolStripMenuItem,
            this.addCustomerToolStripMenuItem,
            this.manageCustomerDetailToolStripMenuItem,
            this.addGameToolStripMenuItem,
            this.manageGameDetailToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // viewAddToolStripMenuItem
            // 
            this.viewAddToolStripMenuItem.Name = "viewAddToolStripMenuItem";
            this.viewAddToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.viewAddToolStripMenuItem.Text = "Add Staff";
            // 
            // manageStaddToolStripMenuItem
            // 
            this.manageStaddToolStripMenuItem.Name = "manageStaddToolStripMenuItem";
            this.manageStaddToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageStaddToolStripMenuItem.Text = "Manage Staff Detail";
            // 
            // addCustomerToolStripMenuItem
            // 
            this.addCustomerToolStripMenuItem.Name = "addCustomerToolStripMenuItem";
            this.addCustomerToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addCustomerToolStripMenuItem.Text = "Add Customer";
            // 
            // manageCustomerDetailToolStripMenuItem
            // 
            this.manageCustomerDetailToolStripMenuItem.Name = "manageCustomerDetailToolStripMenuItem";
            this.manageCustomerDetailToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageCustomerDetailToolStripMenuItem.Text = "Manage Customer Detail";
            // 
            // addGameToolStripMenuItem
            // 
            this.addGameToolStripMenuItem.Name = "addGameToolStripMenuItem";
            this.addGameToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addGameToolStripMenuItem.Text = "Add Game";
            // 
            // manageGameDetailToolStripMenuItem
            // 
            this.manageGameDetailToolStripMenuItem.Name = "manageGameDetailToolStripMenuItem";
            this.manageGameDetailToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageGameDetailToolStripMenuItem.Text = "Manage Game Detail";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.overdueGamesToolStripMenuItem,
            this.accountTransactionToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(54, 20);
            this.toolStripMenuItem2.Text = "Report";
            // 
            // overdueGamesToolStripMenuItem
            // 
            this.overdueGamesToolStripMenuItem.Name = "overdueGamesToolStripMenuItem";
            this.overdueGamesToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.overdueGamesToolStripMenuItem.Text = "Overdue Games";
            // 
            // accountTransactionToolStripMenuItem
            // 
            this.accountTransactionToolStripMenuItem.Name = "accountTransactionToolStripMenuItem";
            this.accountTransactionToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.accountTransactionToolStripMenuItem.Text = "Account Transaction";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataBackupToolStripMenuItem,
            this.dataRestoreToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(93, 20);
            this.toolStripMenuItem3.Text = "System Utilitis";
            // 
            // dataBackupToolStripMenuItem
            // 
            this.dataBackupToolStripMenuItem.Name = "dataBackupToolStripMenuItem";
            this.dataBackupToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.dataBackupToolStripMenuItem.Text = "Data Backup";
            // 
            // dataRestoreToolStripMenuItem
            // 
            this.dataRestoreToolStripMenuItem.Name = "dataRestoreToolStripMenuItem";
            this.dataRestoreToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.dataRestoreToolStripMenuItem.Text = "Data Restore";
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetPasswordToolStripMenuItem});
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.settingToolStripMenuItem.Text = "Setting";
            // 
            // resetPasswordToolStripMenuItem
            // 
            this.resetPasswordToolStripMenuItem.Name = "resetPasswordToolStripMenuItem";
            this.resetPasswordToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.resetPasswordToolStripMenuItem.Text = "Reset Password";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // staffList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 572);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this._numstf);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.liststfdata);
            this.Name = "staffList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "staffList";
            ((System.ComponentModel.ISupportInitialize)(this.liststfdata)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView liststfdata;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label _numstf;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Edit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn type;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox a_box;
        private System.Windows.Forms.TextBox pn_box;
        private System.Windows.Forms.TextBox e_box;
        private System.Windows.Forms.TextBox dh_box;
        private System.Windows.Forms.TextBox cn_box;
        private System.Windows.Forms.TextBox dob_box;
        private System.Windows.Forms.TextBox g_box;
        private System.Windows.Forms.TextBox sn_box;
        private System.Windows.Forms.TextBox fn_box;
        private System.Windows.Forms.TextBox sid_box;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox tp_box;
        private System.Windows.Forms.Button save;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageStaddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageCustomerDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageGameDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem overdueGamesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountTransactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem dataBackupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataRestoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetPasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    }
}
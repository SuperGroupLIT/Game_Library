﻿namespace Game_Library
{
    partial class newStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this._dob = new System.Windows.Forms.DateTimePicker();
            this._gender = new System.Windows.Forms.ComboBox();
            this._dthire = new System.Windows.Forms.DateTimePicker();
            this._type = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this._ppsn = new System.Windows.Forms.TextBox();
            this._email = new System.Windows.Forms.TextBox();
            this._contact = new System.Windows.Forms.TextBox();
            this._address = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this._sname = new System.Windows.Forms.TextBox();
            this._fname = new System.Windows.Forms.TextBox();
            this._stfid = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.add = new System.Windows.Forms.Button();
            this.reset = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(12, 83);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(658, 315);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this._dob);
            this.tabPage1.Controls.Add(this._gender);
            this.tabPage1.Controls.Add(this._dthire);
            this.tabPage1.Controls.Add(this._type);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this._ppsn);
            this.tabPage1.Controls.Add(this._email);
            this.tabPage1.Controls.Add(this._contact);
            this.tabPage1.Controls.Add(this._address);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this._sname);
            this.tabPage1.Controls.Add(this._fname);
            this.tabPage1.Controls.Add(this._stfid);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(650, 289);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Staff details";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // _dob
            // 
            this._dob.CustomFormat = "dd-mm-yyyy";
            this._dob.Location = new System.Drawing.Point(424, 33);
            this._dob.Name = "_dob";
            this._dob.Size = new System.Drawing.Size(153, 20);
            this._dob.TabIndex = 5;
            // 
            // _gender
            // 
            this._gender.FormattingEnabled = true;
            this._gender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this._gender.Location = new System.Drawing.Point(126, 152);
            this._gender.Name = "_gender";
            this._gender.Size = new System.Drawing.Size(153, 21);
            this._gender.TabIndex = 3;
            // 
            // _dthire
            // 
            this._dthire.CustomFormat = "dd-mm-yyyy";
            this._dthire.Location = new System.Drawing.Point(424, 233);
            this._dthire.Name = "_dthire";
            this._dthire.Size = new System.Drawing.Size(153, 20);
            this._dthire.TabIndex = 10;
            // 
            // _type
            // 
            this._type.FormattingEnabled = true;
            this._type.Items.AddRange(new object[] {
            "Manager",
            "Staff"});
            this._type.Location = new System.Drawing.Point(424, 193);
            this._type.Name = "_type";
            this._type.Size = new System.Drawing.Size(153, 21);
            this._type.TabIndex = 9;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(332, 197);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 13);
            this.label12.TabIndex = 23;
            this.label12.Text = "Employee Type: ";
            // 
            // _ppsn
            // 
            this._ppsn.Location = new System.Drawing.Point(424, 152);
            this._ppsn.Name = "_ppsn";
            this._ppsn.Size = new System.Drawing.Size(153, 20);
            this._ppsn.TabIndex = 8;
            this._ppsn.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxEmpty_Validating);
            // 
            // _email
            // 
            this._email.Location = new System.Drawing.Point(424, 113);
            this._email.Name = "_email";
            this._email.Size = new System.Drawing.Size(153, 20);
            this._email.TabIndex = 7;
            this._email.Validating += new System.ComponentModel.CancelEventHandler(this._email_Validating);
            // 
            // _contact
            // 
            this._contact.Location = new System.Drawing.Point(424, 73);
            this._contact.Name = "_contact";
            this._contact.Size = new System.Drawing.Size(153, 20);
            this._contact.TabIndex = 6;
            this._contact.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxEmpty_Validating);
            // 
            // _address
            // 
            this._address.Location = new System.Drawing.Point(126, 193);
            this._address.Multiline = true;
            this._address.Name = "_address";
            this._address.Size = new System.Drawing.Size(153, 60);
            this._address.TabIndex = 4;
            this._address.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxEmpty_Validating);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(361, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Contact #:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(342, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Email Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(377, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "PPS #:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(360, 236);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Date Hire: ";
            // 
            // _sname
            // 
            this._sname.Location = new System.Drawing.Point(126, 115);
            this._sname.Name = "_sname";
            this._sname.Size = new System.Drawing.Size(153, 20);
            this._sname.TabIndex = 2;
            this._sname.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxEmpty_Validating);
            // 
            // _fname
            // 
            this._fname.Location = new System.Drawing.Point(126, 76);
            this._fname.Name = "_fname";
            this._fname.Size = new System.Drawing.Size(153, 20);
            this._fname.TabIndex = 1;
            this._fname.Validating += new System.ComponentModel.CancelEventHandler(this.textBoxEmpty_Validating);
            // 
            // _stfid
            // 
            this._stfid.Location = new System.Drawing.Point(126, 36);
            this._stfid.Name = "_stfid";
            this._stfid.ReadOnly = true;
            this._stfid.Size = new System.Drawing.Size(153, 20);
            this._stfid.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(69, 196);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Address: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(347, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Date of birth: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(72, 155);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Gender: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 122);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Secound Name: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "First Name: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Staff ID: ";
            // 
            // add
            // 
            this.add.Location = new System.Drawing.Point(201, 425);
            this.add.Name = "add";
            this.add.Size = new System.Drawing.Size(75, 23);
            this.add.TabIndex = 0;
            this.add.Text = "Add";
            this.add.UseVisualStyleBackColor = true;
            this.add.Click += new System.EventHandler(this.button1_Click);
            // 
            // reset
            // 
            this.reset.Location = new System.Drawing.Point(299, 425);
            this.reset.Name = "reset";
            this.reset.Size = new System.Drawing.Size(75, 23);
            this.reset.TabIndex = 1;
            this.reset.Text = "Reset";
            this.reset.UseVisualStyleBackColor = true;
            this.reset.Click += new System.EventHandler(this.reset_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(395, 425);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(75, 23);
            this.cancel.TabIndex = 2;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // newStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(682, 495);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.reset);
            this.Controls.Add(this.add);
            this.Controls.Add(this.tabControl1);
            this.Name = "newStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "newStaff";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker _dthire;
        private System.Windows.Forms.ComboBox _type;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox _ppsn;
        private System.Windows.Forms.TextBox _email;
        private System.Windows.Forms.TextBox _contact;
        private System.Windows.Forms.TextBox _address;
        private System.Windows.Forms.TextBox _sname;
        private System.Windows.Forms.TextBox _fname;
        private System.Windows.Forms.TextBox _stfid;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button add;
        private System.Windows.Forms.Button reset;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.ComboBox _gender;
        private System.Windows.Forms.DateTimePicker _dob;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Library
{
    class Person
    {
        public string _fName { get; set; }
        public string _sName { get; set; }
        public string _gender { get; set; }
        public string _email { get; set; }
        public string _contactNo { get; set; }
        public string _dob { get; set; }
        public string _address { get; set; }
        public string _fullname;
        public string fullname
        {
            get { return _fullname; }
            set {this._fullname=_fName+ ' '+_sName;}
        }

        public Person() { }
        public Person(string fullname, string email) {
            this._fullname = fullname;
            this._email = email;
        }
        public Person(string fname, string sname, string email, string gender, string contactno, string dob, string address)
        {
            this._fName = fname;
            this._sName = sname;
            this._gender = gender;
            this._email = email;
            this._contactNo = contactno;
            this._dob = dob;
            this._address = address;
        }
        //public ~Person() { }

    }
}

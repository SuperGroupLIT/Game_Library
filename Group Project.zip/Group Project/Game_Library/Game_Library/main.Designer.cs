﻿namespace Game_Library
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(main));
            this.label1 = new System.Windows.Forms.Label();
            this.editdelstf = new System.Windows.Forms.Button();
            this.editdelcust = new System.Windows.Forms.Button();
            this.editdelgame = new System.Windows.Forms.Button();
            this.custlist = new System.Windows.Forms.Button();
            this.addcust = new System.Windows.Forms.Button();
            this.addstf = new System.Windows.Forms.Button();
            this.stflist = new System.Windows.Forms.Button();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageStaddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageCustomerDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageGameDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overdueGamesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountTransactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.systemUtilitisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataRestoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addgame = new System.Windows.Forms.Button();
            this.gamelist = new System.Windows.Forms.Button();
            this.acctrans = new System.Windows.Forms.Button();
            this.overduegame = new System.Windows.Forms.Button();
            this.resretgame = new System.Windows.Forms.Button();
            this.availablegame = new System.Windows.Forms.Button();
            this.logout = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 28F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(58, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 44);
            this.label1.TabIndex = 1;
            this.label1.Text = "Menu";
            // 
            // editdelstf
            // 
            this.editdelstf.AllowDrop = true;
            this.editdelstf.BackColor = System.Drawing.Color.Lime;
            this.editdelstf.FlatAppearance.BorderSize = 0;
            this.editdelstf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editdelstf.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.editdelstf.Location = new System.Drawing.Point(213, 400);
            this.editdelstf.Name = "editdelstf";
            this.editdelstf.Size = new System.Drawing.Size(254, 120);
            this.editdelstf.TabIndex = 2;
            this.editdelstf.Text = "Update / Delete Staff";
            this.editdelstf.UseVisualStyleBackColor = false;
            this.editdelstf.Click += new System.EventHandler(this.button1_Click);
            // 
            // editdelcust
            // 
            this.editdelcust.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.editdelcust.FlatAppearance.BorderSize = 0;
            this.editdelcust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editdelcust.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.editdelcust.Location = new System.Drawing.Point(326, 148);
            this.editdelcust.Name = "editdelcust";
            this.editdelcust.Size = new System.Drawing.Size(254, 120);
            this.editdelcust.TabIndex = 3;
            this.editdelcust.Text = "Update / Delete Customer";
            this.editdelcust.UseVisualStyleBackColor = false;
            this.editdelcust.Click += new System.EventHandler(this.button2_Click);
            // 
            // editdelgame
            // 
            this.editdelgame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.editdelgame.FlatAppearance.BorderSize = 0;
            this.editdelgame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.editdelgame.Location = new System.Drawing.Point(65, 274);
            this.editdelgame.Name = "editdelgame";
            this.editdelgame.Size = new System.Drawing.Size(254, 120);
            this.editdelgame.TabIndex = 4;
            this.editdelgame.Text = "Update / Delete Game";
            this.editdelgame.UseVisualStyleBackColor = false;
            this.editdelgame.Click += new System.EventHandler(this.button3_Click);
            // 
            // custlist
            // 
            this.custlist.BackColor = System.Drawing.Color.Yellow;
            this.custlist.FlatAppearance.BorderSize = 0;
            this.custlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.custlist.Location = new System.Drawing.Point(65, 148);
            this.custlist.Name = "custlist";
            this.custlist.Size = new System.Drawing.Size(142, 120);
            this.custlist.TabIndex = 5;
            this.custlist.Text = "Customer List";
            this.custlist.UseVisualStyleBackColor = false;
            this.custlist.Click += new System.EventHandler(this.button4_Click);
            // 
            // addcust
            // 
            this.addcust.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.addcust.FlatAppearance.BorderSize = 0;
            this.addcust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addcust.Location = new System.Drawing.Point(213, 148);
            this.addcust.Name = "addcust";
            this.addcust.Size = new System.Drawing.Size(107, 120);
            this.addcust.TabIndex = 6;
            this.addcust.Text = "Add Customer";
            this.addcust.UseVisualStyleBackColor = false;
            this.addcust.Click += new System.EventHandler(this.button5_Click);
            // 
            // addstf
            // 
            this.addstf.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.addstf.FlatAppearance.BorderSize = 0;
            this.addstf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addstf.Location = new System.Drawing.Point(473, 400);
            this.addstf.Name = "addstf";
            this.addstf.Size = new System.Drawing.Size(107, 120);
            this.addstf.TabIndex = 7;
            this.addstf.Text = "Add Staff";
            this.addstf.UseVisualStyleBackColor = false;
            this.addstf.Click += new System.EventHandler(this.button6_Click);
            // 
            // stflist
            // 
            this.stflist.BackColor = System.Drawing.Color.Yellow;
            this.stflist.FlatAppearance.BorderSize = 0;
            this.stflist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.stflist.Location = new System.Drawing.Point(586, 400);
            this.stflist.Name = "stflist";
            this.stflist.Size = new System.Drawing.Size(142, 120);
            this.stflist.TabIndex = 8;
            this.stflist.Text = "Staff List";
            this.stflist.UseVisualStyleBackColor = false;
            this.stflist.Click += new System.EventHandler(this.button7_Click);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAddToolStripMenuItem,
            this.manageStaddToolStripMenuItem,
            this.addCustomerToolStripMenuItem,
            this.manageCustomerDetailToolStripMenuItem,
            this.addGameToolStripMenuItem,
            this.manageGameDetailToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // viewAddToolStripMenuItem
            // 
            this.viewAddToolStripMenuItem.Name = "viewAddToolStripMenuItem";
            this.viewAddToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.viewAddToolStripMenuItem.Text = "Add Staff";
            // 
            // manageStaddToolStripMenuItem
            // 
            this.manageStaddToolStripMenuItem.Name = "manageStaddToolStripMenuItem";
            this.manageStaddToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageStaddToolStripMenuItem.Text = "Manage Staff Detail";
            // 
            // addCustomerToolStripMenuItem
            // 
            this.addCustomerToolStripMenuItem.Name = "addCustomerToolStripMenuItem";
            this.addCustomerToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addCustomerToolStripMenuItem.Text = "Add Customer";
            // 
            // manageCustomerDetailToolStripMenuItem
            // 
            this.manageCustomerDetailToolStripMenuItem.Name = "manageCustomerDetailToolStripMenuItem";
            this.manageCustomerDetailToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageCustomerDetailToolStripMenuItem.Text = "Manage Customer Detail";
            // 
            // addGameToolStripMenuItem
            // 
            this.addGameToolStripMenuItem.Name = "addGameToolStripMenuItem";
            this.addGameToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addGameToolStripMenuItem.Text = "Add Game";
            // 
            // manageGameDetailToolStripMenuItem
            // 
            this.manageGameDetailToolStripMenuItem.Name = "manageGameDetailToolStripMenuItem";
            this.manageGameDetailToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageGameDetailToolStripMenuItem.Text = "Manage Game Detail";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.overdueGamesToolStripMenuItem,
            this.accountTransactionToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // overdueGamesToolStripMenuItem
            // 
            this.overdueGamesToolStripMenuItem.Name = "overdueGamesToolStripMenuItem";
            this.overdueGamesToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.overdueGamesToolStripMenuItem.Text = "Overdue Games";
            // 
            // accountTransactionToolStripMenuItem
            // 
            this.accountTransactionToolStripMenuItem.Name = "accountTransactionToolStripMenuItem";
            this.accountTransactionToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.accountTransactionToolStripMenuItem.Text = "Account Transaction";
            // 
            // systemUtilitisToolStripMenuItem
            // 
            this.systemUtilitisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataBackupToolStripMenuItem,
            this.dataRestoreToolStripMenuItem});
            this.systemUtilitisToolStripMenuItem.Name = "systemUtilitisToolStripMenuItem";
            this.systemUtilitisToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
            this.systemUtilitisToolStripMenuItem.Text = "System Utilitis";
            // 
            // dataBackupToolStripMenuItem
            // 
            this.dataBackupToolStripMenuItem.Name = "dataBackupToolStripMenuItem";
            this.dataBackupToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.dataBackupToolStripMenuItem.Text = "Data Backup";
            // 
            // dataRestoreToolStripMenuItem
            // 
            this.dataRestoreToolStripMenuItem.Name = "dataRestoreToolStripMenuItem";
            this.dataRestoreToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.dataRestoreToolStripMenuItem.Text = "Data Restore";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.systemUtilitisToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(902, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // addgame
            // 
            this.addgame.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.addgame.FlatAppearance.BorderSize = 0;
            this.addgame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addgame.Location = new System.Drawing.Point(326, 274);
            this.addgame.Name = "addgame";
            this.addgame.Size = new System.Drawing.Size(107, 120);
            this.addgame.TabIndex = 10;
            this.addgame.Text = "Add Game";
            this.addgame.UseVisualStyleBackColor = false;
            this.addgame.Click += new System.EventHandler(this.button8_Click);
            // 
            // gamelist
            // 
            this.gamelist.BackColor = System.Drawing.Color.Yellow;
            this.gamelist.FlatAppearance.BorderSize = 0;
            this.gamelist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gamelist.Location = new System.Drawing.Point(438, 274);
            this.gamelist.Name = "gamelist";
            this.gamelist.Size = new System.Drawing.Size(142, 120);
            this.gamelist.TabIndex = 9;
            this.gamelist.Text = "Game List";
            this.gamelist.UseVisualStyleBackColor = false;
            this.gamelist.Click += new System.EventHandler(this.button9_Click);
            // 
            // acctrans
            // 
            this.acctrans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.acctrans.FlatAppearance.BorderSize = 0;
            this.acctrans.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.acctrans.ForeColor = System.Drawing.SystemColors.ControlText;
            this.acctrans.Location = new System.Drawing.Point(65, 400);
            this.acctrans.Name = "acctrans";
            this.acctrans.Size = new System.Drawing.Size(142, 120);
            this.acctrans.TabIndex = 11;
            this.acctrans.Text = "Account Transaction";
            this.acctrans.UseVisualStyleBackColor = false;
            this.acctrans.Click += new System.EventHandler(this.button10_Click);
            // 
            // overduegame
            // 
            this.overduegame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.overduegame.FlatAppearance.BorderSize = 0;
            this.overduegame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.overduegame.Location = new System.Drawing.Point(587, 148);
            this.overduegame.Name = "overduegame";
            this.overduegame.Size = new System.Drawing.Size(107, 120);
            this.overduegame.TabIndex = 12;
            this.overduegame.Text = "Overdue Games";
            this.overduegame.UseVisualStyleBackColor = false;
            this.overduegame.Click += new System.EventHandler(this.button11_Click);
            // 
            // resretgame
            // 
            this.resretgame.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.resretgame.FlatAppearance.BorderSize = 0;
            this.resretgame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.resretgame.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.resretgame.Location = new System.Drawing.Point(587, 274);
            this.resretgame.Name = "resretgame";
            this.resretgame.Size = new System.Drawing.Size(153, 120);
            this.resretgame.TabIndex = 13;
            this.resretgame.Text = "Reserve / Return";
            this.resretgame.UseVisualStyleBackColor = false;
            this.resretgame.Click += new System.EventHandler(this.button12_Click);
            // 
            // availablegame
            // 
            this.availablegame.BackColor = System.Drawing.Color.LightCoral;
            this.availablegame.FlatAppearance.BorderSize = 0;
            this.availablegame.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.availablegame.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.availablegame.Location = new System.Drawing.Point(700, 148);
            this.availablegame.Name = "availablegame";
            this.availablegame.Size = new System.Drawing.Size(107, 120);
            this.availablegame.TabIndex = 14;
            this.availablegame.Text = "Available Games";
            this.availablegame.UseVisualStyleBackColor = false;
            this.availablegame.Click += new System.EventHandler(this.button13_Click);
            // 
            // logout
            // 
            this.logout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.logout.FlatAppearance.BorderSize = 0;
            this.logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.logout.Location = new System.Drawing.Point(813, 38);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(77, 31);
            this.logout.TabIndex = 15;
            this.logout.Text = "Logout";
            this.logout.UseVisualStyleBackColor = false;
            this.logout.Click += new System.EventHandler(this.button14_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(902, 572);
            this.Controls.Add(this.logout);
            this.Controls.Add(this.availablegame);
            this.Controls.Add(this.resretgame);
            this.Controls.Add(this.overduegame);
            this.Controls.Add(this.acctrans);
            this.Controls.Add(this.addgame);
            this.Controls.Add(this.gamelist);
            this.Controls.Add(this.stflist);
            this.Controls.Add(this.addstf);
            this.Controls.Add(this.addcust);
            this.Controls.Add(this.custlist);
            this.Controls.Add(this.editdelgame);
            this.Controls.Add(this.editdelcust);
            this.Controls.Add(this.editdelstf);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "main";
            this.Load += new System.EventHandler(this.main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button editdelstf;
        private System.Windows.Forms.Button editdelcust;
        private System.Windows.Forms.Button editdelgame;
        private System.Windows.Forms.Button custlist;
        private System.Windows.Forms.Button addcust;
        private System.Windows.Forms.Button addstf;
        private System.Windows.Forms.Button stflist;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem systemUtilitisToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button addgame;
        private System.Windows.Forms.Button gamelist;
        private System.Windows.Forms.Button acctrans;
        private System.Windows.Forms.Button overduegame;
        private System.Windows.Forms.ToolStripMenuItem viewAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageStaddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageCustomerDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageGameDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overdueGamesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountTransactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataBackupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataRestoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button resretgame;
        private System.Windows.Forms.Button availablegame;
        private System.Windows.Forms.Button logout;
    }
}
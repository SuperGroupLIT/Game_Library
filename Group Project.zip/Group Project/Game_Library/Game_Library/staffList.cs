﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Game_Library
{
    public partial class staffList : Form
    {
        public staffList()
        {
            InitializeComponent();
            loadstf();
            liststaffs();
            _numstf.Text = liststf.Count.ToString();//show number of staffs
        }
        List<Employee> liststf = new List<Employee>();
        public string staffid;
        //=========================load staff from text file=========================//
        public void loadstf()
        {
            liststf = new List<Employee>();
            using (StreamReader sr = new StreamReader(@"data\employee.txt"))
            {
                while (!sr.EndOfStream)
                {
                    string[] lineinfo = sr.ReadLine().Split(' ');
                    liststf.Add(new Employee() { _stfID = lineinfo[0], _fName = lineinfo[1],_sName=lineinfo[2],_gender=lineinfo[3], _email = lineinfo[4],_address=lineinfo[5],
                       _contactNo=lineinfo[6], _ppsNo=lineinfo[7], _emplyType = lineinfo[8], _dob=lineinfo[9],_dateHire=lineinfo[10],_psw=lineinfo[11]});
                }
            }
        }

        //=========================show staffs on datagridview=========================//
        public void liststaffs()
        {
            //BindingList<Employee> liststf = new BindingList<Employee>();
            using (StreamReader sr = new StreamReader(@"data\employee.txt"))
            {
                while (!sr.EndOfStream)
                {
                    string[] lineinfo = sr.ReadLine().Split(' ');
                    //liststf.Add(new Employee() { _stfID = lineinfo[0], _fullname = lineinfo[1] + ' ' + lineinfo[2], _email = lineinfo[4], _emplyType = lineinfo[8] });
                    liststfdata.Rows.Add(lineinfo[0], lineinfo[1] + ' ' + lineinfo[2], lineinfo[4], lineinfo[8]);
                }
            }
        }

        //=========================selecte 1 row of staff infomation=========================//
        public void selectRow()
        {
            loadstf();

            if (liststfdata.SelectedRows.Count == 1)
            {
                DataGridViewRow row = this.liststfdata.SelectedRows[0];
                try
                {
                    staffid = row.Cells["idNum"].Value.ToString();
                }
                catch(NullReferenceException)
                {
                    //MessageBox.Show("No Obejct selected!\n");
                }
            }
            stfdetail(staffid);
        }

        //=========================Show detail on right hand side when selected=========================//
        public void stfdetail(string stfid)
        {
            foreach(Employee a in liststf)
            {
                if(a._stfID==stfid)
                {
                    sid_box.Text=a._stfID;
                    fn_box.Text=a._fName;
                    sn_box.Text=a._sName;
                    tp_box.Text = a._emplyType;
                    g_box.Text=a._gender;
                    dob_box.Text=a._dob;
                    cn_box.Text=a._contactNo; 
                    e_box.Text=a._email;
                    pn_box.Text=a._ppsNo;
                    dh_box.Text=a._dateHire;
                    a_box.Text=a._address;
                }
            }
        }

        //=========================allow to edit details=========================//
        private void Edit_Click(object sender, EventArgs e)
        {
            if (liststfdata.SelectedRows.Count == 1)
            {
                fn_box.ReadOnly = false;
                sn_box.ReadOnly = false;
                tp_box.ReadOnly = false;
                g_box.ReadOnly = false;
                dob_box.ReadOnly = false;
                cn_box.ReadOnly = false;
                e_box.ReadOnly = false;
                pn_box.ReadOnly = false;
                dh_box.ReadOnly = false;
                a_box.ReadOnly = false;
            }
            else
                MessageBox.Show("No staff selected!");

        }
        //=========================Delete a selected staff=========================//
        private void Delete_Click(object sender, EventArgs e)
        {
            if (liststfdata.SelectedRows.Count == 1)
            {
                int index=0;
                foreach(Employee a in liststf)
                {
                    if(a._stfID==sid_box.Text)
                        break;
                    index++;
                }
                liststf.RemoveAt(index);

                string[] stfarray = liststf.Select(i => i.ToString()).ToArray();
                File.WriteAllLines(@"data\employee.txt", stfarray);
                MessageBox.Show("Staff Deleted!");
            }
            else
                MessageBox.Show("No staff selected!");

            int pos = liststfdata.SelectedRows[0].Index;
            liststfdata.Rows.RemoveAt(pos);

        }
        //=========================Exit=========================//
        private void Exit_Click(object sender, EventArgs e)
        {
            Close();
        }

        //=========================Get values when row selected=========================//
        private void liststfdata_SelectionChanged(object sender, EventArgs e)
        {
            selectRow();
        }

        //=========================save detail after changes=========================//
        private void save_Click(object sender, EventArgs e)
        {
            if (liststfdata.SelectedRows.Count == 1)
            {
                string[] allData = File.ReadAllLines(@"data\employee.txt");
                for (int i = 0; i < allData.Length; i++)
                {
                    if (allData[i].Contains(sid_box.Text))
                    {
                        string[] lineinfo = allData[i].Split(' ');
                        lineinfo[1] = fn_box.Text;
                        lineinfo[2] = sn_box.Text;
                        lineinfo[3] = g_box.Text;
                        lineinfo[4] = e_box.Text;
                        lineinfo[5] = a_box.Text;
                        lineinfo[6] = cn_box.Text;
                        lineinfo[7] = pn_box.Text;
                        lineinfo[8] = tp_box.Text;
                        lineinfo[9] = dob_box.Text;
                        lineinfo[10] = dh_box.Text;

                        allData[i] = lineinfo[0] + ' ' + lineinfo[1] + ' ' +
                                            lineinfo[2] + ' ' + lineinfo[3] + ' ' +
                                            lineinfo[4] + ' ' + lineinfo[5] + ' ' +
                                            lineinfo[6] + ' ' + lineinfo[7] + ' ' +
                                            lineinfo[8] + ' ' + lineinfo[9] + ' ' +
                                            lineinfo[10] + ' ' + lineinfo[11];

                        liststfdata.SelectedRows[0].Cells[1].Value = lineinfo[1] + " " + lineinfo[2];
                        liststfdata.SelectedRows[0].Cells[2].Value = lineinfo[4];
                        liststfdata.SelectedRows[0].Cells[3].Value = lineinfo[8];
                    }
                }
                File.WriteAllLines(@"data\employee.txt", allData);
                MessageBox.Show("Employee detail updated!");
                fn_box.ReadOnly = true;
                sn_box.ReadOnly = true;
                tp_box.ReadOnly = true;
                g_box.ReadOnly = true;
                dob_box.ReadOnly = true;
                cn_box.ReadOnly = true;
                e_box.ReadOnly = true;
                pn_box.ReadOnly = true;
                dh_box.ReadOnly = true;
                a_box.ReadOnly = true;
            }
            else
                MessageBox.Show("No staff selected!");
        }

       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Library
{
    class Employee : Person
    {
        public string _stfID { get; set; }
        public string _ppsNo { get; set; }
        public string _emplyType { get; set; }
        public string _dateHire { get; set; }
        public string _psw { get; set; }

        public Employee() { }
        //public ~Employee() { }
        public Employee(string stfid, string fullname, string email, string emtype)
            :base(fullname, email)
        {
            this._stfID = stfid;
            this._emplyType = emtype;
        }
        public Employee(string stfid, string fname, string sname, string email, string gender, string contactno, string dob,
            string ppsn, string emtype, string datehire, string address,string psw)
            : base(fname, sname, email, gender, contactno, dob, address)
        {
            this._stfID = stfid;
            this._ppsNo = ppsn;
            this._emplyType = emtype;
            this._dateHire = datehire;
            this._psw = psw;
        }
    }
}

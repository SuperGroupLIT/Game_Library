﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Game_Library
{
    public partial class newStaff : Form
    {
        public newStaff()
        {
            InitializeComponent();
            add.Enabled = false;
            Employee addstf = new Employee();
            Random randomstfid = new Random();
            _stfid.Text = randomstfid.Next(1000000, 99999999).ToString();
            _gender.SelectedIndex = 0;
            _type.SelectedIndex = 1;
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
        }


        private string pswGen()//-----random password Generator------//
        {
            string randpsw = string.Empty;
            char[] pwdCharArray = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".ToCharArray();
            Random r1 = new Random();
            for(int i=0; i<10;i++)
            {
                int point = r1.Next(1, pwdCharArray.Length);
                if (!randpsw.Contains(pwdCharArray.GetValue(point).ToString()))
                    randpsw += pwdCharArray.GetValue(point);
            }
            return randpsw;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string stfid = _stfid.Text;
            string dob = _dob.Value.ToString("dd-mm-yyyy");
            string dthire = _dthire.Value.ToString("dd-mm-yyyy");

            string gender = _gender.Text;
            string type = _type.Text;

            string fname = _fname.Text;
            string sname = _sname.Text;
            string email = _email.Text;
            string address = _address.Text;
            string ppsn = _ppsn.Text;
            string contact = _contact.Text;
            string psw = pswGen();
            using (StreamWriter stf = new StreamWriter(@"data\employee.txt",true))
            {
                stf.WriteLine(stfid + ' ' + fname + ' ' + sname + ' ' + gender + ' ' + email + ' ' + address + ' ' + contact + ' ' + ppsn + ' ' + type + ' ' + dthire + ' ' + dob + ' ' + psw);
                //stf.Flush();
                //stf.Close();
                
            }
            MessageBox.Show("Employee Add!");
            Close();
        }

        private void reset_Click(object sender, EventArgs e)
        {
            _contact.Clear();
            _address.Clear();
            _email.Clear();
            _fname.Clear();
            _sname.Clear();
            _ppsn.Clear();
            _gender.SelectedIndex = 0;
            _type.SelectedIndex = 1;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void ValidateOK()
        {
            if (_fname.Text.Length != 0 && _sname.Text.Length != 0
                           && _address.Text.Length != 0
                           && _contact.Text.Length != 0
                           && _ppsn.Text.Length != 0
                           && _email.Text.Length != 0)
                add.Enabled = true;
        }

        private void textBoxEmpty_Validating(object sender, CancelEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if (tb.Text.Length == 0)
                tb.BackColor = Color.Coral;
            else
                tb.BackColor = System.Drawing.SystemColors.Window;
            ValidateOK();
        }

        private void _email_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (_email.Text.Length > 0)
            {
                if (!rEMail.IsMatch(_email.Text))
                {
                    MessageBox.Show("Email Address verification failed! Try again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    _email.SelectAll();
                    e.Cancel = true;
                }
            }
        }
    }
}

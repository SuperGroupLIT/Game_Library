﻿namespace Game_Library
{
    partial class overdueGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.Exit = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idNum = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageStaddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageCustomerDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageGameDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.overdueGamesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountTransactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.dataBackupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataRestoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetPasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(203, 43);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 33;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // searchBox
            // 
            this.searchBox.Location = new System.Drawing.Point(35, 43);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(162, 20);
            this.searchBox.TabIndex = 32;
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(861, 54);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 29);
            this.Exit.TabIndex = 30;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.textBox1.Location = new System.Drawing.Point(588, 105);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(352, 467);
            this.textBox1.TabIndex = 36;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idNum,
            this.name,
            this.email,
            this.Column1,
            this.Status});
            this.dataGridView1.Location = new System.Drawing.Point(0, 105);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(579, 467);
            this.dataGridView1.TabIndex = 35;
            // 
            // idNum
            // 
            this.idNum.HeaderText = "Customer ID";
            this.idNum.Name = "idNum";
            // 
            // name
            // 
            this.name.HeaderText = "Game Title";
            this.name.Name = "name";
            this.name.Width = 150;
            // 
            // email
            // 
            this.email.HeaderText = "Brorrow Date";
            this.email.Name = "email";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Return Date";
            this.Column1.Name = "Column1";
            // 
            // Status
            // 
            this.Status.HeaderText = "Sattus";
            this.Status.Name = "Status";
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.settingToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.Size = new System.Drawing.Size(940, 24);
            this.menuStrip2.TabIndex = 41;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewAddToolStripMenuItem,
            this.manageStaddToolStripMenuItem,
            this.addCustomerToolStripMenuItem,
            this.manageCustomerDetailToolStripMenuItem,
            this.addGameToolStripMenuItem,
            this.manageGameDetailToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "File";
            // 
            // viewAddToolStripMenuItem
            // 
            this.viewAddToolStripMenuItem.Name = "viewAddToolStripMenuItem";
            this.viewAddToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.viewAddToolStripMenuItem.Text = "Add Staff";
            // 
            // manageStaddToolStripMenuItem
            // 
            this.manageStaddToolStripMenuItem.Name = "manageStaddToolStripMenuItem";
            this.manageStaddToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageStaddToolStripMenuItem.Text = "Manage Staff Detail";
            // 
            // addCustomerToolStripMenuItem
            // 
            this.addCustomerToolStripMenuItem.Name = "addCustomerToolStripMenuItem";
            this.addCustomerToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addCustomerToolStripMenuItem.Text = "Add Customer";
            // 
            // manageCustomerDetailToolStripMenuItem
            // 
            this.manageCustomerDetailToolStripMenuItem.Name = "manageCustomerDetailToolStripMenuItem";
            this.manageCustomerDetailToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageCustomerDetailToolStripMenuItem.Text = "Manage Customer Detail";
            // 
            // addGameToolStripMenuItem
            // 
            this.addGameToolStripMenuItem.Name = "addGameToolStripMenuItem";
            this.addGameToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.addGameToolStripMenuItem.Text = "Add Game";
            // 
            // manageGameDetailToolStripMenuItem
            // 
            this.manageGameDetailToolStripMenuItem.Name = "manageGameDetailToolStripMenuItem";
            this.manageGameDetailToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.manageGameDetailToolStripMenuItem.Text = "Manage Game Detail";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(205, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.overdueGamesToolStripMenuItem,
            this.accountTransactionToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(54, 20);
            this.toolStripMenuItem2.Text = "Report";
            // 
            // overdueGamesToolStripMenuItem
            // 
            this.overdueGamesToolStripMenuItem.Name = "overdueGamesToolStripMenuItem";
            this.overdueGamesToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.overdueGamesToolStripMenuItem.Text = "Overdue Games";
            // 
            // accountTransactionToolStripMenuItem
            // 
            this.accountTransactionToolStripMenuItem.Name = "accountTransactionToolStripMenuItem";
            this.accountTransactionToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.accountTransactionToolStripMenuItem.Text = "Account Transaction";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataBackupToolStripMenuItem,
            this.dataRestoreToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(93, 20);
            this.toolStripMenuItem3.Text = "System Utilitis";
            // 
            // dataBackupToolStripMenuItem
            // 
            this.dataBackupToolStripMenuItem.Name = "dataBackupToolStripMenuItem";
            this.dataBackupToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.dataBackupToolStripMenuItem.Text = "Data Backup";
            // 
            // dataRestoreToolStripMenuItem
            // 
            this.dataRestoreToolStripMenuItem.Name = "dataRestoreToolStripMenuItem";
            this.dataRestoreToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.dataRestoreToolStripMenuItem.Text = "Data Restore";
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetPasswordToolStripMenuItem});
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.settingToolStripMenuItem.Text = "Setting";
            // 
            // resetPasswordToolStripMenuItem
            // 
            this.resetPasswordToolStripMenuItem.Name = "resetPasswordToolStripMenuItem";
            this.resetPasswordToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.resetPasswordToolStripMenuItem.Text = "Reset Password";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // overdueGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 572);
            this.Controls.Add(this.menuStrip2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.Exit);
            this.Name = "overdueGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "overdueGame";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn name;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageStaddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageCustomerDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageGameDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem overdueGamesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountTransactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem dataBackupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataRestoreToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetPasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
    }
}
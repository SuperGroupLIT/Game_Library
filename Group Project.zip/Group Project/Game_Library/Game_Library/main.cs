﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game_Library
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            staffList a = new staffList();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            customerList a = new customerList();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            gameList a = new gameList();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            gameList a = new gameList();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            newStaff a = new newStaff();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            newGame a = new newGame();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            newCustomer a = new newCustomer();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            staffList a = new staffList();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            customerList a = new customerList();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            accTransaction a = new accTransaction();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            overdueGame a = new overdueGame();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void main_Load(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            availableGames a = new availableGames();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            ReserveReturn a = new ReserveReturn();
            a.ShowDialog();
            a = null;
            Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
